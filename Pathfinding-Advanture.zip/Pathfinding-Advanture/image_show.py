from easygui import *
from easygui_get_input import *

def get_image_input(image = ""):
    return get_input("solve for answer",image)
